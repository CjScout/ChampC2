setup.exe /configure Configuration-wordonly.xml
